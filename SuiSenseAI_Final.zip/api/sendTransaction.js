
export default async function handler(req, res) {
  const { transactionData } = req.body;

  try {
    res.status(200).json({
      status: 'mock sent',
      transactionData
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
