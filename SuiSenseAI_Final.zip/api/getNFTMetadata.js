
export default async function handler(req, res) {
  const { tokenId } = req.query;

  try {
    const response = await fetch(`https://fullnode.devnet.sui.io/v1`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jsonrpc: '2.0',
        id: 1,
        method: 'sui_getObject',
        params: [tokenId, { showContent: true }]
      })
    });

    const data = await response.json();
    res.status(200).json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
