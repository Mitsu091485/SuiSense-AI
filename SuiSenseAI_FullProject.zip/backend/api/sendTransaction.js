
import sendTransaction from '../sendTransaction.js';
import mockWalletSignIn from '../mockWallet.js';

export default async function handler(req, res) {
  const { transactionData } = req.body;
  const wallet = await mockWalletSignIn();
  const response = await sendTransaction(wallet.address, transactionData);
  res.status(200).json(response);
}
