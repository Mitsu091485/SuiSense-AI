
import getNFTMetadata from '../getNFTMetadata.js';

export default async function handler(req, res) {
  const { tokenId } = req.query;
  const data = await getNFTMetadata(tokenId);
  res.status(200).json(data);
}
